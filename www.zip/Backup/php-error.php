<style type="text/css">@import url("style.css");</style>
<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<title>PHP error</title>
<h1>PHP error</h1>

<pre>
&lt;?php
echo $some;
?&gt;
</pre>

<?php
echo $some;
?>
