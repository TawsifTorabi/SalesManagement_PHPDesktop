<style type="text/css">@import url("style.css");</style>
<a href="index.php">Go back to index</a>
| <a href="<?php echo $_SERVER["REQUEST_URI"];?>">Refresh</a>

<title>Google</title>
<h1>Google</h1>

<a href="https://www.google.com/">https://www.google.com/</a>
