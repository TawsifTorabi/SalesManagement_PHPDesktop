#About
This fork of canvg provides compatibility with the c2d plugin.
Several changes needed to be made to ensure that our _fake_ 
canvas is compatible with the canvg rendering engine.

This library was copied from [https://github.com/Flamenco/canvg](https://github.com/Flamenco/canvg).

#Usage
For examples converting HTML pages and SVG elements into PDF using canvg and the context2d plugin,
see the examples in the /examples/canvg_context2d directory.