<?php
ob_start();
require('mpdf/mpdf.php');
$mpdf=new mPDF();


//$mpdf=new mPDF('','A4',14,'kalpurush');
$mpdf->useAdobeCJK=true;
$mpdf->SetAutoFont(AUTOFONT_ALL);
//$mpdf->WriteHTML(file_get_contents('fonts/mpdf.css'),1);
$html = $_GET['html'];
$dhtml = base64_decode($html);

//$string = str_replace(' ', '', $html);

//$html=ob_get_contents();
$mpdf->WriteHTML($html);
//$mpdf->SetDisplayMode('fullpage');
$mpdf->debug = true;
$mpdf->Output();

exit;
?>
